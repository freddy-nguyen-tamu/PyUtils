import os
from mutagen.easyid3 import EasyID3
from mutagen.mp3 import MP3

# Hardcoded folder path
MP3_FOLDER = r"C:\Users\qacer\Downloads\downloads"

# Hardcoded metadata for all MP3 files
metadata_list = []

# Loop through the metadata and update MP3 tags
for metadata in metadata_list:
    file_path = os.path.join(MP3_FOLDER, metadata["file_name"])
    
    if os.path.exists(file_path):
        try:
            audio = MP3(file_path, ID3=EasyID3)
        except Exception:
            audio = MP3(file_path)
            audio.add_tags()
        
        # Update title, artist, and genre
        if "title" in metadata:
            audio["title"] = metadata["title"]
        if "artist" in metadata:
            audio["artist"] = metadata["artist"]
        if "genre" in metadata:
            audio["genre"] = metadata["genre"]
        
        audio.save()
        print(f"Updated: {metadata['file_name']}")
    else:
        print(f"File not found: {metadata['file_name']}")